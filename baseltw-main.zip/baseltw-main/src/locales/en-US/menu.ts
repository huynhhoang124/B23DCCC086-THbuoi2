export default {
  'menu.login': 'Đăng nhập',
  'menu.account': 'Tài khoản',
  'menu.account.center': 'Cá nhân',
  'menu.Dashboard': 'Trang chủ',
  'menu.News': 'Tin tức',

  'menu.DanhMuc': 'Danh mục',
  'menu.DanhMuc.ChucVu': 'Chức vụ',
  'menu.DanhMuc.LoaiPhongBan': 'Loại phòng ban',
};
