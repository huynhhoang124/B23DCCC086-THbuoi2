export const unTechnicalSupportPaths = ['/user/login', '/403', '/notification/check', '/notification/subscribe'];
