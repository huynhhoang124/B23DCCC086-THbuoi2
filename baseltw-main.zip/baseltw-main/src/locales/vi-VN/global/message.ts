export default {
	'global.message.themmoithanhcong': 'Thêm mới thành công',
	'global.message.luuthanhcong': 'Lưu thành công',
	'global.message.xoathanhcong': 'Xóa thành công',
	'global.message.validated': 'Đã kiểm tra dữ liệu',
	'global.message.imported': 'Đã nhập dữ liệu',
	'global.message.formsubmiting': 'Đang gửi dữ liệu',
};
