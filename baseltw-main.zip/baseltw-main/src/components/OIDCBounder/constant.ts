export const unAuthPaths = ['/notification', '/notification/check'];

export const unCheckPermissionPaths = ['/notification/subscribe'];
