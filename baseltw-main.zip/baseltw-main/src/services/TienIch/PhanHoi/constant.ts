export enum ELoaiPhanHoi {
	DVMC = 'Dịch vụ 1 cửa',
	KHAC = 'Khác',
	KY_THUAT = 'Kỹ thuật',
}
